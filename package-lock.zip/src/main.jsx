import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const App = () => {
  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>Welcome to Sufiyan's World</h1>
      <p>"Thank you for visiting! Goodbye and take care!".</p>
      <img
        src="https://c1.wallpaperflare.com/preview/849/616/935/desk-tech-setup-web-development.jpg"
        alt="Apple iMac on Desk"
        style={{ width: '500px', borderRadius: '10px', margin: '20px 0' }}
      />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
